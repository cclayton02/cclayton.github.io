// IT-145 Final Project - Monitoring System
// Filename: MonitoringSystem.java
// Author: Charles Clayton
// Email: charles.clayton@snhu.edu

package monitoringsystem;

import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MonitoringSystem {

   public static void displayMainMenu() {

      // Print the Main Menu options
      System.out.println("Welcome to the Zookeper Monitoring System");
      System.out.println();
      System.out.println("(A)nimal Monitor");
      System.out.println("(H)abitat Monitor");
      System.out.println("(E)xit Program");
      System.out.println();
   }

   // MAIN PROGRAM BEGINS
   public static void main(String[] args) throws FileNotFoundException {

      Scanner input = new Scanner(System.in);

      char userChoice;
      int userSubChoice;
      int listSize;
      String fileString = "";
      
      // Relative path to text file information
      String animalsPath = "src/monitoringsystem/animals.txt";
      String habitatsPath = "src/monitoringsystem/habitats.txt";

      displayMainMenu();
      System.out.println("Please select an option:");

      while (true) {
         
         // User selects a choice from Main Menu
         userChoice = input.next().toLowerCase().charAt(0);
         if ((userChoice == 'a') | (userChoice == 'h')) {

            switch (userChoice) {

               case 'a':
                  System.out.println("Loading animals.txt...");
                  fileString = DataFile.createFileString(animalsPath);
                  break;

               case 'h':
                  System.out.println("Loading habitats.txt...");
                  fileString = DataFile.createFileString(habitatsPath);
                  break;
            }

            // Check that loaded files are valid before using
            if (!DataFile.isValidFile(fileString)) {
               System.out.println("Error: Invalid File");
               break;
            }
            listSize = DataFile.displaySubMenu(fileString);

            while (true) {
            System.out.println("Please select another option: ");

               // User selects a choice from the sub menu
               try {
                  userSubChoice = Integer.parseInt(input.next().substring(0, 1));

                  if ((userSubChoice > 0) & userSubChoice < listSize) {

                     DataFile.displayMonitor(userSubChoice, fileString);
                     System.out.println("Display Complete.");
                     System.out.println("Press Enter to continue...");

                     try {
                        System.in.read();
                     } catch (IOException e) {
                     }

                     DataFile.displaySubMenu(fileString);
                  } else if (userSubChoice == listSize) {
                     System.out.println("Returning to previous menu...");
                     System.out.println();
                     displayMainMenu();
                     System.out.println("Please select an option:");
                     break;
                  }
               } catch (NumberFormatException e) {
                  System.out.println("Invalid choice, please try again: ");
               }
            }

         } // Exit Program
         else if (userChoice == 'e') {
            System.out.println("Exiting program... goodbye!");
            input.close();
            break;
         }
         else {
            System.out.println("Invalid choice, please try again:");
         }
      }
   }
}
