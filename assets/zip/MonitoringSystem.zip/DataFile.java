// IT-145 Final Project - Monitoring System
// Filename: DataFile.java
// Author: Charles Clayton
// Email: charles.clayton@snhu.edu

package monitoringsystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class DataFile {
   
   public static void displayMonitor(int choice, String file) {
      
      Scanner scnr = new Scanner(file);
      int count = 0;
      String currentLine = "!";
      
      while (scnr.hasNextLine()) {
         currentLine = scnr.nextLine();
         if (currentLine.equals("")) {
            // Reached a break in sections; increment list counter
            count++;
            if (count == choice) {
               // Located user choice; print display information
               System.out.println(currentLine);
               currentLine = scnr.nextLine();
               while (scnr.hasNextLine() & !currentLine.equals("")) {
                  System.out.println(displayAlert(currentLine));
                  currentLine = scnr.nextLine();
               }
               // Fix bug to catch information at end of file stream
               if (!scnr.hasNextLine()) {
                  System.out.println(displayAlert(currentLine));
               }
               System.out.println();
               break;
            }
         }
      }
   }

   public static String createFileString(String filePath) throws FileNotFoundException {
      
      String currentLine;
      String newString = "";
      File file = new File(filePath);
      Scanner scnr = new Scanner(file);
      
      // Use File contents to build string for analysis
      while (scnr.hasNextLine()) {
         currentLine = scnr.nextLine() + "\n";
         newString += currentLine;
      }
      return newString;
   }

   public static String displayAlert(String line) {
      
      if (line.length() >= 5) {
         if (line.substring(0, 5).equals("*****")) {
            // Create frame and dialog message
            JFrame frame = new JFrame();
            frame.setVisible(true);
            frame.setLocation(100, 100);
            frame.setAlwaysOnTop(true);
            String alertLine = line.substring(5) + "\n\nPress OK to Continue";
            JOptionPane.showMessageDialog(frame, alertLine, "Alert Warning", 1);
            
            frame.dispose();
         }
      }
      return line;
   }

   public static boolean isValidFile(String fileName) {
      
      // Check that file is valid and return true or false
      Scanner file = new Scanner(fileName);
      boolean headerSearched = false;
      int numHeaderItems = 0;
      int numBodyItems = 0;
      String currentLine = " ";
      
      while (file.hasNextLine()) {
         currentLine = file.nextLine();
         while (!currentLine.equals("") & (!headerSearched)) {
            // Begin header counting
            numHeaderItems++;
            currentLine = file.nextLine();
         }
         headerSearched = true;
         if (currentLine.equals("")) {
            numBodyItems++;
         }
      }
      if (numHeaderItems == numBodyItems) {
         return true;
      }
      // Print information for invalid file
      System.out.println("ERROR: File is not valid.");
      System.out.println("Number of header items: " + numHeaderItems);
      System.out.println("Number of body items: " + numBodyItems);
      return false;
   }

   public static int displaySubMenu(String fileName) {
      
      Scanner file = new Scanner(fileName);
      int i = 1;
      String currentLine = " ";
      
      // Begin display of menu options
      System.out.println();
      while (file.hasNextLine() & !currentLine.equals("")) {
         currentLine = file.nextLine();
         if (!currentLine.equals("")) {
            System.out.println("" + i + " - " + currentLine);
            i++;
         }
      }
      // Reached end of header information
      System.out.println("" + i + " - Return to main menu");
      System.out.println();
      // Returning our total list size
      return i;
   }
    
}
