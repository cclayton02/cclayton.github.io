CREATE DATABASE [MonitoringSystemBlazor]
GO

ALTER DATABASE [MonitoringSystemBlazor] SET QUERY_STORE=ON
GO
